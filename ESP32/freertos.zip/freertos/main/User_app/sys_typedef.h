#ifndef _SYS_TYPEDEF__H_
#define _SYS_TYPEDEF__H_

#include "stdint.h"
#include "stdbool.h"






/*  DATA    */
#define DATAMAX     1024
#define RXBUFFMAX   DATAMAX
#define TXBUFFMAX   DATAMAX



#endif
